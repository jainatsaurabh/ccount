package com.example.virus.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.virus.entity.Cities;

@Repository
public interface CityRepo extends JpaRepository<Cities, Integer> {

	@Query(value = "select * from cities where ccode=?1", nativeQuery = true)
	public Cities findCity(String name);

}
