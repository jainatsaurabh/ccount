package com.example.virus.serve;

import java.util.Date;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.virus.entity.Cities;
import com.example.virus.entity.States;
import com.example.virus.repo.CityRepo;
import com.example.virus.repo.StateRepo;

@Service
public class ServeState {

	@Autowired
	StateRepo srepo;

	@Autowired
	CityRepo crepo;

	public Object saveCityIn(Cities c) {
		c.setDate(new Date().toString());
		c.setTotal(c.getActive() + c.getDecease() + c.getRecover());
		String findc = c.getCcode();
		if (crepo.findCity("findc") == null) {

			return crepo.save(c);
		} else {
			Cities c1 = crepo.findCity("findc");
			return crepo.save(new Cities(c.getCcode(), c1.getActive() + c.getActive(), c1.getTotal() + c.getTotal(),
					c1.getDecease() + c.getDecease(), c1.getRecover() + c.getRecover(), c.getDate()));
		}

	}

}
